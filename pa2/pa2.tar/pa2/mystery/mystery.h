#ifndef _MYSTERY_H_
#define _MYSTERY_H_

int add(int, int);

int compute_fib(int);

#endif